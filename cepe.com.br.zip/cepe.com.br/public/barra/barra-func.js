$(document).ready(function(){
  $('.barra-global .btn-plus').click(function(){
    $(".barra-global .menubar").slideToggle("slow");
  });
});