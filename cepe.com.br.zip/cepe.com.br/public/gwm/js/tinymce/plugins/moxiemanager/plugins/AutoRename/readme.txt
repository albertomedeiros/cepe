Auto Rename Plugin
Add these config options to your config.php file in moxiemanager.

$moxieManagerConfig['autorename.enabled'] = true;
$moxieManagerConfig['autorename.spacechar'] = "_";
$moxieManagerConfig['autorename.lowercase'] = false;

Then, add "AutoRename" to your $moxieManagerConfig["plugins"] config option.