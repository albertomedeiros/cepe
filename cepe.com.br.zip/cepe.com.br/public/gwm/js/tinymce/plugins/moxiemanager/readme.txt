moxiemanager-php-pro - build: 2.1.7-24

Documentation
-----------------
For detailed documentation, please see the following location:
https://www.tinymce.com/docs/plugins/

Support
-----------------
For further support, please use the Ephox Support website, located here: https://support.ephox.com/home
