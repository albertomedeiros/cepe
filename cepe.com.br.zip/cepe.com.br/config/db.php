<?php

$conf = new Fishy_Configuration();

$conf->host = 'localhost';
$conf->user = 'root';
$conf->password = 'mysql@intra';
$conf->database = 'fishyfw_site';

return $conf;